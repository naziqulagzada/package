from setuptools import setup

setup(
    name="package",
    version="0.1",
    description="mypackage is just a practice.",
    author="nazia",
    author_email="nqulagzada@gmail.com",
    url="https://github.com/naziqulagzada/package.git",
    license="MIT",
    packages=["mypackage"],
    install_requires=["requests"],
    zip_safe=False

)