from setuptools import setup

setup(
    name="pakage",
    version= "0.1",
    description="",
    author="nazia",
    author_email="nqulag@gmail.com",
    url="https://github.com/naziqulagzada/package",
    license='MIT',
    install_requires="pandas",
    zip_safe= False

)